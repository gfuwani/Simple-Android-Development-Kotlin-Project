package com.example.praca6

import android.os.Bundle
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    lateinit var rg: RadioGroup
    lateinit var rbRunning: RadioButton
    lateinit var rbSwimming: RadioButton
    lateinit var rbBasketball: RadioButton
    lateinit var tv_show: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initializeViews()
        setupListeners()
    }

    private fun initializeViews(){
        rg=findViewById(R.id.rg)
        rbRunning=findViewById(R.id.rbRunning)
        rbSwimming=findViewById(R.id.rbSwimming)
        rbBasketball=findViewById(R.id.rbBasketball)
        tv_show=findViewById(R.id.tv_show)

    }

    private fun setupListeners(){
        rg.setOnCheckedChangeListener { group, checkedId->
            val rb=findViewById<RadioButton>(checkedId)
            tv_show.text=(rb.text)
        }
    }
}