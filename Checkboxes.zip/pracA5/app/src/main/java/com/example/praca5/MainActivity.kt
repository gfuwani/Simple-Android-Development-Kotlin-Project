package com.example.praca5

import android.os.Bundle
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var cbRunning: CheckBox
    lateinit var cbBasketball: CheckBox
    lateinit var cbSwimming: CheckBox
    lateinit var tvState: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initializeViews()
        setupListeners()
    }

    private fun initializeViews(){
        cbRunning=findViewById(R.id.cbRunning)
        cbBasketball=findViewById(R.id.cbBasketball)
        cbSwimming=findViewById(R.id.cbSwimming)
        tvState=findViewById(R.id.tvState)
    }

    private fun setupListeners() {
        cbRunning.setOnCheckedChangeListener { _: CompoundButton?,_: Boolean->
            if(cbRunning.isChecked){
                cbBasketball.isChecked=false
                cbSwimming.isChecked=false
            }
            updateCheckboxes()
        }

        cbBasketball.setOnCheckedChangeListener { _: CompoundButton?, _: Boolean->
            if(cbBasketball.isChecked){
                cbRunning.isChecked=false
                cbSwimming.isChecked=false
            }
            updateCheckboxes()
        }

        cbSwimming.setOnCheckedChangeListener { _: CompoundButton?, _: Boolean->
            if(cbSwimming.isChecked){
                cbRunning.isChecked=false
                cbBasketball.isChecked=false
            }
            updateCheckboxes()
        }
    }

    private fun updateCheckboxes(){
        var s =""
        if(cbRunning.isChecked){
            s=cbRunning.text.toString()
        }

        if(cbBasketball.isChecked){
            s=cbBasketball.text.toString()
        }

        if(cbSwimming.isChecked){
            s=cbSwimming.text.toString()
        }

        tvState.text=s

    }
}