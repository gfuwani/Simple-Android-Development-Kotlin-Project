package com.example.prac1a

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.newSingleThreadContext

class MainActivity : AppCompatActivity() {
    lateinit var edtName: EditText
    lateinit var rg: RadioGroup
    lateinit var rbMale: RadioButton
    lateinit var rbFemale: RadioButton
    lateinit var edtAge: EditText
    lateinit var edtProfession: EditText

    lateinit var btEnter: Button
    lateinit var tvPersonal_Info: TextView

    lateinit var tvName: TextView
    lateinit var tvGender: TextView
    lateinit var tvAge: TextView
    lateinit var tvProfession: TextView
    lateinit var btClear: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        intitializeViews()
        setupListeners()

    }

    private fun intitializeViews(){
        edtName=findViewById(R.id.edtName)
        rg=findViewById(R.id.rg)
        rbMale=findViewById(R.id.rbMale)
        rbFemale=findViewById(R.id.rbFemale)
        edtAge=findViewById(R.id.edtAge)
        edtProfession=findViewById(R.id.edtProfession)

        btEnter=findViewById(R.id.btEnter)
        tvPersonal_Info=findViewById(R.id.tvPersonal_info)

        tvName=findViewById(R.id.tvName)
        tvGender=findViewById(R.id.tvGender)
        tvAge=findViewById(R.id.tvAge)
        tvProfession=findViewById(R.id.tvProfession)

        btClear=findViewById(R.id.btClear)
    }

    private fun setupListeners(){
        rg.setOnCheckedChangeListener { group, checkedId->
            if(checkedId!= -1){
                val rb=findViewById<RadioButton>(checkedId)
                tvGender.text=("Gender: ${rb.text}")
            }
        }

        btEnter.setOnClickListener {
            tvPersonal_Info.text="Personal info"
            tvName.text="Full Name: ${edtName.text}"
            tvAge.text="Age: ${edtAge.text}"
            tvProfession.text="Profession: ${edtProfession.text}"

        }

        btClear.setOnClickListener {
            edtName.text.clear()
            rg.clearCheck()
            edtAge.text.clear()
            edtProfession.text.clear()
            tvName.text=""
            tvGender.text=""
            tvAge.text=""
            tvProfession.text=""
        }
    }
}