package com.example.praca_main

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var edtName: EditText
    lateinit var btGetName: Button
    lateinit var tvShowName: TextView
    lateinit var rg: RadioGroup
    lateinit var rbRunning: RadioButton
    lateinit var rbSwimming: RadioButton
    lateinit var rbBasketball: RadioButton
    lateinit var cbRed: CheckBox
    lateinit var cbGreen: CheckBox
    lateinit var cbBlue: CheckBox
    lateinit var tvRadioButton: TextView
    lateinit var tvCheckbox: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        initializeViews()
        setupListeners()
    }

    private fun initializeViews(){
        edtName=findViewById(R.id.edtName)
        btGetName=findViewById(R.id.btGetName)
        tvShowName=findViewById(R.id.tvShowName)
        rg=findViewById(R.id.rg)
        rbRunning=findViewById(R.id.rbRunning)
        rbSwimming=findViewById(R.id.rbSwimming)
        rbBasketball=findViewById(R.id.rbBasketball)
        cbRed=findViewById(R.id.cbRed)
        cbGreen=findViewById(R.id.cbGreen)
        cbBlue=findViewById(R.id.cbBlue)
        tvRadioButton=findViewById(R.id.tvRadioButton)
        tvCheckbox=findViewById(R.id.tvCheckbox)
    }

    private fun setupListeners(){
        btGetName.setOnClickListener {
            tvShowName.text=edtName.text
        }

        rg.setOnCheckedChangeListener {group, checkedId ->
            val rb=findViewById<RadioButton>(checkedId)
            tvRadioButton.text=rb.text
        }

        cbRed.setOnCheckedChangeListener{_:CompoundButton,_:Boolean ->
            if(cbRed.isChecked){
                cbGreen.isChecked=false
                cbBlue.isChecked=false
                tvCheckbox.text=cbRed.text
                tvCheckbox.setTextColor(Color.RED)
            }
        }

        cbGreen.setOnCheckedChangeListener { _:CompoundButton,_: Boolean->
            if(cbGreen.isChecked){
                cbRed.isChecked=false
                cbBlue.isChecked=false
                tvCheckbox.text=cbGreen.text
                tvCheckbox.setTextColor(Color.GREEN)
            }
        }

        cbBlue.setOnCheckedChangeListener { _:CompoundButton,_: Boolean->
            if(cbBlue.isChecked){
                cbRed.isChecked=false
                cbGreen.isChecked=false
                tvCheckbox.text=cbBlue.text
                tvCheckbox.setTextColor(Color.BLUE)
            }
        }
    }
}